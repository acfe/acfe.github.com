#!/bin/bash
cd project
cd $1
git pull origin $2
