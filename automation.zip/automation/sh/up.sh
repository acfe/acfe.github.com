#!/bin/bash
cd project
cd $1
mkdir output
cd output
mkdir bak
cd bak
dirdate=`date +%Y%m%d`_`date +%H%M%S`
mkdir $dirdate
scp -r $4$3 $dirdate
cd ../
rm -rf $3
mv $2 $3 
scp -r $3 $4
