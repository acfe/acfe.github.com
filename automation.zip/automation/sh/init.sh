#!/bin/bash
if [ $1 != "" ]
	then
	cd project
	rm -rf $1
	if [ $2 != "" ]
    	then
    	git clone $2
    fi
fi