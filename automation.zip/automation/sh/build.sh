#!/bin/bash
cd project
cd $1
node scripts/build/conf.js $2
node scripts/build/html.js
ln -s ../../node_modules node_modules
rm -rf output/$2
npm run build
