#!/bin/bash
cd project
cd $1
mkdir output
cd output
scp -r $3 $4
