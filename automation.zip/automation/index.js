const express = require('express');
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const ejs = require('ejs');
const serverList = require('./server/config/servers');

const getIPAdress = () => {
    var interfaces = require('os').networkInterfaces();
    for (var devName in interfaces) {
        var iface = interfaces[devName];
        for (var i = 0; i < iface.length; i++) {
            var alias = iface[i];
            if (alias.family === 'IPv4' && alias.address !== '127.0.0.1' && !alias.internal) {
                return alias.address;
            }
        }
    }
}

app.use(express.static('client/output/online'));
app.set('views', 'client/output/online');
app.engine('html', ejs.__express);
app.set('view engine', 'html');

app.all('*', (req, res, next) => {
    res.header('Access-Control-Allow-Origin', 'http://' + getIPAdress() + ':3001');
    res.header('Access-Control-Allow-Credentials', true);
    next();
});

app.get('/', (req, res)  => {
    res.render('index', { title: 'automation'});
});

app.get('/socket', (req, res) => {
    res.json({
        serverList
    });
});

const { onBuild, onInitialize, onDirectUp } = require('./server/socket');

io.on('connection', function (socket) {
    socket.on('build', onBuild);
    socket.on('directUp', onDirectUp);
    socket.on('initialize', onInitialize);
    socket.on('disconnect', (data) => {
        console.log(data);
    });
});

const server = http.listen(3000, function () {
    const host = server.address().address;
    const port = server.address().port;
	console.log('app listening at http://%s:%s', host, port);
});