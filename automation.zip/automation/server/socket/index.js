/**
 * Created by cxj on 2017/12/23.
 */
const { exec } = require('child_process');
const fs = require('fs');

const execCallback = function (err, stdout, stderr) {
    if (err) {
        this.emit('message', { err });
    }
}

const onBuild = async function(data) {
    const projectName = data.project;
    const project = data.project;
    if(!fs.existsSync('project/' + projectName)) {
        this.emit('message', { text: '项目未初始化，请选初始化项目', project, finish: true });
        return;
    }
    this.emit('message', { text: '更新项目代码', project });
    this.broadcast.emit('message', { text: '更新项目代码', project });
    exec('do.sh pull ' + projectName + ' ' + data.gitBranch, (err, stdout, stderr) => {
        this.emit('message', { text: '构建项目', project });
        this.broadcast.emit('message', { text: '构建项目', project });
        exec('do.sh build ' + projectName + ' ' + data.env, (err, stdout, stderr) => {
            this.emit('message', { text: '备份-更新项目', project });
            this.broadcast.emit('message', { text: '备份-更新项目', project });
            const ftpDir = data.ftpUser + '@' + data.ftpHost + ':' + data.ftpDir;
            exec('do.sh up ' + projectName + ' ' + data.env + ' ' + data.ftpFolder + ' ' + ftpDir, (err, stdout, stderr) => {
                this.emit('message', { text: '发版完成', project, finish: true });
                this.broadcast.emit('message', { text: '发版完成', project, finish: true });
            });
        });
    });
}

const onDirectUp = async function(data) {
    const projectName = data.project;
    const project = data.project;
    if(!fs.existsSync('project/' + projectName)) {
        this.emit('message', { text: '项目未初始化，请选初始化项目', project, finish: true });
        return;
    }
    this.emit('message', { text: '上传项目代码', project });
    this.broadcast.emit('message', { text: '上传项目代码', project });
    const ftpDir = data.ftpUser + '@' + data.ftpHost + ':' + data.ftpDir;
    exec('do.sh direct_up ' + projectName + ' ' + data.env + ' ' + data.ftpFolder + ' ' + ftpDir, (err, stdout, stderr) => {
        this.emit('message', { text: '上传完成', project, finish: true });
        this.broadcast.emit('message', { text: '上传完成', project, finish: true });
    });
}

const onInitialize = async function(data) {
    this.emit('message', { text: '初始化项目' });
    this.broadcast.emit('message', { text: '初始化项目' });
    if(!fs.existsSync('project')) {
        await fs.mkdir('project');
    }
    const project = data.project;
    await exec('do.sh init ' + data.project + ' ' + data.gitUrl, (err, stdout, stderr) => {
        this.emit('message', { text: '初始化完成', project, finish: true });
        this.broadcast.emit('message', { text: '初始化完成', project, finish: true });
    });
}

module.exports = {
    onBuild,
    onDirectUp,
    onInitialize
}