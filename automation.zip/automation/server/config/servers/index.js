/**
 * Created by cxj on 2017/12/23.
 */

const mall_frontend = require('./mall_frontend');
const mall_backend = require('./mall_backend');

module.exports = [
    mall_frontend,
    mall_backend,
]