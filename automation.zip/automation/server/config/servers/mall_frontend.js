/**
 * Created by cxj on 2017/12/23.
 */

module.exports = {
    project: 'mall_frontend', //项目目录
    projectName: '电商前端', //项目名称
    projectDescription: '',//项目描述
    env: 'test',//构建环境
    gitBranch: 'develop',//git 拉取分支
    gitUrl: 'git@gitlab@fcbox.com:mall_frontend',//git 地址
    ftps: [
        {
            ftpHost: '10.204.56.75',//ftp 地址
            ftpUser: 'appdeploy',//ftp 用户名
            ftpDir: '/app/nginx/html/mall.fcbox.com/mall-sit2.fcbox.com/',//项目远端路径 项目文件夹的完整父路径
            ftpFolder: 'frontend'//项目远端文件夹名
        }
    ]
}