#!/bin/bash
if [ $1 == "init" ] || [ $1 == "build" ] || [ $1 == "pull" ]
	then
	sh/$1.sh $2 $3
fi

if [ $1 == "up" ]  || [ $1 == "direct_up" ]
	then
	sh/$1.sh $2 $3 $4 $5
fi
