#!/bin/bash
if [ $1 == "server" ]
	then
	node scripts/build/conf.js local
	node scripts/build/html.js
	npm run start
else
	if [ $2 == "test" ]
		then
		node scripts/build/conf.js test
	elif [ $2 == "online" ]
		then
		node scripts/build/conf.js online
	else
		node scripts/build/conf.js local
	fi
	node scripts/build/html.js
	
	if [ $1 == "build" ] && [ $2 != "local" ]
		then
		if [ $3 == "watch" ]
			then
			npm run watch
		else
			rm -rf output/$2
			npm run build
		fi
	fi
	
	if [ $2 == "test" ] && [ $3 == "up" ]
		then
		mkdir output/bak
		cd output/bak
		dirdate=`date +%Y%m%d`_`date +%H%M%S`
		mkdir $dirdate
		scp -r appdeploy@10.204.56.75:/app/nginx/html/mall.fcbox.com/mall-sit2.fcbox.com/frontend $dirdate
		cd ../
		rm -rf frontend
		mv test frontend 
		scp -r frontend appdeploy@10.204.56.75:/app/nginx/html/mall.fcbox.com/mall-sit2.fcbox.com/
	fi
fi