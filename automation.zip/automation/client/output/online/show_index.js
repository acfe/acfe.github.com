const publicPath = '/';

var index = function () {
    this.init();
}

index.prototype =  {

    init: function () {
        this.getProjectData();
    },

    getProjectData: function () {
        var show = this.getQueryString('show', location.search);
        show = show || 'index';
        var head = document.getElementsByTagName('head')[0];
        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.type = 'text/css';
        link.href = publicPath + 'css/' + show + '.css?0.24104586847875997';
        head.appendChild(link);
        var loadArr = [];
        loadArr.push(publicPath + 'js/vendor.js?0.24104586847875997');
        loadArr.push(publicPath + 'js/' + show + '.js?0.24104586847875997');
        require(loadArr);
    },

    getQueryString: function (name, urlSearch) {
        if (!urlSearch) {
            return false;
        }
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = urlSearch.substr(1).match(reg);
        return r ? r[2] : false;
    }

};

new index();