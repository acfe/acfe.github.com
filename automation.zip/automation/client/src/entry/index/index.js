import 'babel-polyfill';
import React from 'react';
import { render } from 'react-dom';
// redux
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';
import thunk from 'redux-thunk';

import reducer from 'src/common/redux/reducers';
const middleware = [thunk];
const store = createStore(
    reducer,
    applyMiddleware(...middleware)
);

// components
import Router from 'fc_react/frontend/router/index';
import Index from 'src/pages/index/containers/index';
import Detail from 'src/pages/index/containers/detail';

render(
    <Provider store={store}>
        <Router>
            <Index page="index"/>
            <Detail page="detail"/>
        </Router>
    </Provider>,
    document.getElementById('app')
);
