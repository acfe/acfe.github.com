import React, {Component} from 'react';
import "src/pages/index/less/index.less";

class Index extends Component {

    constructor(props, context) {
        super(props, context);
    }

    componentDidMount() {
        const { state, setData } = this.props;
        document.title = 'automation';
        if(state.pageLoaded) {
            return;
        }
        const { onSocket } = this.props;
        onSocket();
        setData({
            key: 'pageLoaded',
            data: true
        });
    }

    go(key) {
        const { state } = this.props;
        state.router.push('detail/' + key);
    }

    renderList() {
        const { state } = this.props;
        if(!state.Index.serverList) {
            return;
        }
        return state.Index.serverList.map((item, key) => {
            return (
                <div className="item" key={key}>
                    <div className="itemContent" onClick={() => this.go(key)}>
                        <div className="image"></div>
                        <div className="name">{item.projectName}</div>
                    </div>
                </div>
            );
        })
    }

    render() {
        const { state } = this.props;
        if (!state.pageLoaded) {
            return (
                <div className="Index">
                    loading...
                </div>
            );
        }
        return (
            <div className="Index">
                <div className="header">
                    Fc frontend | 丰巢前端自动化管理后台
                </div>
                <div className="listContent clearFix">
                    {this.renderList()}
                </div>
            </div>
        );
    }

}

export default Index;
