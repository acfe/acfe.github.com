import React, {Component} from 'react';
import "src/pages/index/less/index.less";

class Detail extends Component {

    constructor(props, context) {
        super(props, context);
    }

    componentDidMount() {

    }

    back() {
        const { state } = this.props;
        state.router.back();
    }

    buildProject(data) {
        const { onBuild } = this.props;
        onBuild(data);
    }

    upProject(data) {
        const { onDirectUp } = this.props;
        onDirectUp(data);
    }

    initializeProject(data) {
        const { onInitialize } = this.props;
        onInitialize(data);
    }

    renderProcess(server) {
        const { state } = this.props;
        if(server.project == state.Index.showProcessProject) {
            return (
                <div className="processPop">
                    <div className="mask"></div>
                    <div className="info">
                        {this.renderProcessText()}
                    </div>
                </div>
            );
        }
    }

    renderProcessText() {
        const { state } = this.props;
        const processInfo = state.Index.processInfo || [];
        return  processInfo.map((item, key) => {
            return (
                <div className="text" key={key}>{item}...</div>
            );
        });
    }

    renderFtps(server) {
        const ftps = server.ftps;
        if(!ftps) {
            return;
        }
        return  ftps.map((item, key) => {
            item.project = server.project;
            item.gitBranch = server.gitBranch;
            item.env = server.env;
            return(
                <div  className="ftpsInfo" key={key}>
                    <table cellPadding="0" cellSpacing="0">
                        <tbody>
                        <tr>
                            <td className="title dark">服务器</td>
                            <td>{item.ftpHost}</td>
                            <td className="title dark">项目目录名</td>
                            <td className="clearFix">
                                {item.ftpFolder}
                                <span className="greenBtn blue" onClick={() => this.buildProject(item)}>发布版本</span>
                                <span className="greenBtn" onClick={() => this.upProject(item)}>直接上传</span>
                            </td>
                        </tr>
                        <tr>
                            <td className="title">完整路径</td>
                            <td  colSpan="3">{item.ftpDir + item.ftpFolder}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            );
        })
    }

    render() {
        const { state } = this.props;
        const key = location.hash.split('/')[1];
        if (!state.pageLoaded || !state.Index.serverList || !key) {
            return (
                <div className="Index">
                    loading...
                </div>
            );
        }
        const serverList = state.Index.serverList;
        const server = serverList[key];
        return (
            <div className="Index">
                <div className="header">
                    Fc frontend | 丰巢前端自动化管理后台
                </div>
                <div className="listContent detailList">
                    <div className="backBar">
                        <span onClick={() => this.back()}>返回</span>
                    </div>
                    <div className="projectInto">
                        <div className="projectTitle">项目信息</div>
                        <table cellPadding="0" cellSpacing="0">
                            <tbody>
                                <tr>
                                    <td className="title dark">项目名称</td>
                                    <td>{server.projectName}</td>
                                    <td className="title dark">项目目录</td>
                                    <td>{server.project}</td>
                                </tr>
                                <tr>
                                    <td className="title">构建环境</td>
                                    <td>{server.env}</td>
                                    <td className="title">Git分支</td>
                                    <td className="clearFix">
                                        {server.gitBranch}
                                        <span className="greenBtn" onClick={() => this.initializeProject(server)}>初始化项目</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td className="title dark">项目描述</td>
                                    <td  colSpan="3">{server.projectDescription}</td>
                                </tr>
                                <tr>
                                    <td className="title">Git地址</td>
                                    <td  colSpan="3">{server.gitUrl}</td>
                                </tr>
                            </tbody>
                        </table>
                        <div className="projectTitle">FTP信息</div>
                        {this.renderFtps(server)}
                        {this.renderProcess(server)}
                    </div>
                </div>
            </div>
        );
    }

}

export default Detail;
