import ajax from "fc_react/utils/ajax";
import { apiHost } from 'src/common/js/env.config.js';
const io = require('socket.io-client');
const socket = io.connect("ws://" + apiHost);

const onShowLoading = () => {
    return {
        type: 'set',
        key: 'showLoading',
        data: true
    }
}

const onSocket = () => {
    return (dispatch, getState) => {
        const state = getState();
        const socketApi = state.config.api.socket;
        const getParam = {
            url: socketApi,
            data: {}
        }
        ajax.get(getParam).then((data) => {
            state.Index.serverList = JSON.parse(data).serverList;
            dispatch({
                type: 'refresh'
            });
            socket.on('message',function (data) {
                console.log(data);
                state.Index.showProcessProject = data.project;
                state.Index.processInfo = state.Index.processInfo || [];
                state.Index.processInfo.push(data.text);
                dispatch({
                    type: 'refresh'
                });
                if(data.finish) {
                    state.Index.processInfo = [];
                    setTimeout(() => {
                        state.Index.showProcessProject = '';
                        dispatch({
                            type: 'refresh'
                        });
                    }, 3000);
                }
            });
        });
    }
}

const onBuild = (data) => {
    return (dispatch, getState) => {
        const state = getState();
        state.Index.showProcessProject = data.project;
        state.Index.processInfo = [];
        dispatch({
            type: 'refresh'
        });
        socket.emit('build', data);
    }
}

const onDirectUp = (data) => {
    return (dispatch, getState) => {
        const state = getState();
        state.Index.showProcessProject = data.project;
        state.Index.processInfo = [];
        dispatch({
            type: 'refresh'
        });
        socket.emit('directUp', data);
    }
}

const onInitialize = (data) => {
    return (dispatch, getState) => {
        const state = getState();
        state.Index.showProcessProject = data.project;
        state.Index.processInfo = [];
        dispatch({
            type: 'refresh'
        });
        socket.emit('initialize', data);
    }
}

export {
    onShowLoading,
    onSocket,
    onInitialize,
    onDirectUp,
    onBuild
}
