import { apiHost, publicPath } from './env.config.js';

class Config {

	constructor() {
		this.init();
	}

	init() {
        this.setApiUrl();
	}

    setApiUrl() {
        this.api = {
            socket: '//' + apiHost + '/socket',
        };
        this.homePage = {
            index: publicPath + 'index.html',
        };
    }

}
export default new Config();