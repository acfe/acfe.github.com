const webHost = '';
const publicPath = '/';
const apiHost = '192.168.0.108:3000';

export {
    webHost,
    apiHost,
    publicPath
}