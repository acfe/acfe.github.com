class Com {

	constructor() {
		this.init();
	}

	init() {
        const docEl = document.documentElement;
        var width = docEl.getBoundingClientRect().width;
        var height = docEl.getBoundingClientRect().height;
        width = document.getElementById('app').clientWidth || width;
        height = document.getElementById('app').clientHeight || height;
        this.width = width;
        this.height = height;
	}

    isPc() {
        const userAgentInfo = navigator.userAgent;
        const Agents = ["Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"];
        let flag = true;
        for (var v = 0; v < Agents.length; v++) {
            if (userAgentInfo.indexOf(Agents[v]) > 0) { flag = false; break; }
        }
        return flag;
    }

}
export default new Com();