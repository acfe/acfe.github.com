const webpack = require('webpack');
const TransferWebpackPlugin = require('transfer-webpack-plugin');
// manifest
const ManifestPlugin = require('webpack-manifest-plugin');
const ExtractTextPlugin = require("extract-text-webpack-plugin");

const pathConfig = require('./path.config');

const path = require('path');
const buildPath = path.resolve(__dirname, '../../output/' + pathConfig.outputPath);

const config = require('./config').config;
const entry = config.entry;

entry.vendor = ['react', 'react-dom', 'react-redux', 'redux', 'redux-thunk', 'react-tap-event-plugin'];

module.exports = {
    entry: entry,
	//devtool: 'source-map',
    output: {
        path: buildPath,
        publicPath: pathConfig.publicPath || "/",
        filename: "js/[name].js",
		chunkFilename: "js/[name].js",
	    //sourceMapFilename: "[name].js.map",
    },
    plugins: [
        new webpack.DefinePlugin({
            'process.env.NODE_ENV': JSON.stringify('production')
        }),
        new webpack.optimize.UglifyJsPlugin({
            compress: {
                warnings: false,
            },
	        //sourceMap: true,
        }),
        new webpack.NoEmitOnErrorsPlugin(),
        new TransferWebpackPlugin([
            {from: 'www'},
        ], path.resolve(__dirname, '../templates')),
        // manifest
        new ManifestPlugin({
            fileName: 'manifest.json'
        }),
        new ExtractTextPlugin("css/[name].css")
    ],
    module: {
        rules: [
            {
                test: /\.js$/,
                loader: "babel-loader"
            },
            {
                test: /\.(png|woff|woff2|eot|ttf|svg|jpg|gif)$/,
                loader: "file-loader",
                query: {name: "images/[name].[ext]"}
            },
            {
                test: /\.css$/,
                use: ExtractTextPlugin.extract("style-loader", "css-loader")
            },
            {
                test: /\.less$/,
                use: ExtractTextPlugin.extract("css-loader!less-loader")
            },
        ],
    },
    resolve: {
        alias: {
            'src': path.resolve(__dirname, '../../src'),
            'fc_react': path.resolve(__dirname, '../../fc_react')
        }
    },
};
