const path = require('path');

const getIPAdress = function() {
    var interfaces = require('os').networkInterfaces();
    for (var devName in interfaces) {
        var iface = interfaces[devName];
        for (var i = 0; i < iface.length; i++) {
            var alias = iface[i];
            if (alias.family === 'IPv4' && alias.address !== '127.0.0.1' && !alias.internal) {
                return alias.address;
            }
        }
    }
}

//env config
var envPath = {
		test: {
			outputPath: 'test',
			publicPath: '/',
            apiHost: getIPAdress() + ':3000',
            webHost: ''
		},
		online: {
			outputPath: 'online',
			publicPath: '/',
            apiHost: getIPAdress() + ':3000',
            webHost: ''
		},
		local: {
			outputPath: 'local',
			publicPath: '/',
            apiHost: getIPAdress() + ':3000',
            webHost: ''
		},
	};

//webpack
const apiHost = '127.0.0.1:3000';
const port = '3001';
const buildType = 1;

const pages = {
    index: 'index',
};

const proxyFolds = [
    '/user/*'
];

const proxyConfig = {
    target: 'http://' + apiHost,
    host: apiHost,
    secure: false,
    changeOrigin: true
}
const proxy = {};
for(var i = 0; i < proxyFolds.length; i++) {
    proxy[proxyFolds[i]] = proxyConfig;
}

const entry = {};
for (var i in pages) {
    entry[i] = path.join(__dirname, '../../src/entry/' + pages[i] + '/index.js');
}

var config = {
    pages,
    envPath,
    entry,
    apiHost,
    port,
    proxy,
    buildType
}

exports.config = config;