
exports.outputPath = 'online';

exports.publicPath = '/';
