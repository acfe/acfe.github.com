const path = require('path');
const webpack = require('webpack');
const buildPath = path.resolve(__dirname, '../../output');
const ExtractTextPlugin = require("extract-text-webpack-plugin");

const config = require('./config').config;
const pathConfig = require('./path.config');
const entry = config.entry;
const port = config.port;
const proxy = config.proxy;

const getIPAdress = function() {
    var interfaces = require('os').networkInterfaces();
    for (var devName in interfaces) {
        var iface = interfaces[devName];
        for (var i = 0; i < iface.length; i++) {
            var alias = iface[i];
            if (alias.family === 'IPv4' && alias.address !== '127.0.0.1' && !alias.internal) {
                return alias.address;
            }
        }
    }
}

entry.vendor = ['react', 'react-dom', 'react-redux', 'redux', 'redux-thunk', 'react-tap-event-plugin'];

module.exports = {
    context: path.resolve(__dirname, '../../src'),
    entry: entry,
    output: {
        path: buildPath,
        filename: "js/[name].js",
		chunkFilename: "js/[name].js",
        publicPath: pathConfig.publicPath || "/",
    },
    devServer: {
        contentBase: path.resolve(__dirname, '../templates/www'),
        hot: true,
        inline: true,
        port,
        host: getIPAdress() || '127.0.0.1',
        proxy
    },
    module: {
        rules: [
            {
                test: /\.js$/,
                loader: "babel-loader"
            },
            {
                test: /\.(png|woff|woff2|eot|ttf|svg|jpg|gif)$/,
                loader: "file-loader",
                query: {name: "images/[name].[hash].[ext]"}
            },
            {
                test: /\.css$/,
                use: ExtractTextPlugin.extract("style-loader", "css-loader")
            },
            {
                test: /\.less$/,
                use: ExtractTextPlugin.extract("css-loader!less-loader")
            },
        ],
    },
    resolve: {
        alias: {
            'src': path.resolve(__dirname, '../../src'),
            'fc_react': path.resolve(__dirname, '../../fc_react')
        }
    },
    plugins: [
        new webpack.HotModuleReplacementPlugin(),
        new ExtractTextPlugin("css/[name].css")
    ]
};