
exports.outputPath = '{outputPath}';

exports.publicPath = '{publicPath}';
