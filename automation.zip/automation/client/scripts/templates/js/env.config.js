const webHost = '{webHost}';
const publicPath = '{publicPath}';
const apiHost = '{apiHost}';

export {
    webHost,
    apiHost,
    publicPath
}